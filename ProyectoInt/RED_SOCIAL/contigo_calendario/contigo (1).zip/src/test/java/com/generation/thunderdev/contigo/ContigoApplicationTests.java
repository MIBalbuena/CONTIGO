package com.generation.thunderdev.contigo;

/*import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;*/

//@SpringBootTest
class ContigoApplicationTests {

	//@Test
	void contextLoads() {
	}

}
